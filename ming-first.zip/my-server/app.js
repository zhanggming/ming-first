const express=require('express');
const bodyParser=require('body-parser');
const userRouter=require('./routes/user.js');
var server=express();
server.listen(3000);
//托管静态文件
server.use(express.static('public'));
//使用body-parser中间件将post请求的数据解析为对象
//写在路由器之前
server.use(bodyParser.urlencoded({
     extended:false
}));
//把用户路由器挂载到/user
server.use('/user',userRouter);