//引入连接池对象
const pool=require('../pool.js');
const express=require('express');
//创建空路由器
var router=express.Router();
//条件路由
//1.用户注册
     router.post('/register',(req,res)=>{
	     var obj=req.body;
		 //console.log(obj);
		 var $code=400;
		 for(var key in obj){
		     $code++;
			 if(!obj[key]){
			     res.send({code:$code,msg:key+'required'});
				 return;
			     }
		     }
	     pool.query('INSERT INTO mc_user SET ?',[obj],(err,result)=>{
		     if(err)throw err;
			 if(result.affectedRows>0){
			     res.send({code:200,msg:'register sucess'});
			 }
		 });
	 
	 });
//2.用户登录
     router.post('/login',(req,res)=>{
	     var obj=req.body;
		 //console.log(obj);
		 var $uname=obj.uname;
		 if(!$uname){
		     res.send({code:401,msg:'uname required'});
		     return;
		 };
		 var $upwd=obj.upwd;
		 if(!$upwd){
		     res.send({code:402,msg:'upwd required'});
			 return;
		 };
		 pool.query('SELECT * FROM mc_user WHERE uname=? AND upwd=?',[$uname,$upwd],(err,result)=>{
		     if(err)throw err;
			 console.log(result);
			 if(result.length>0){
			     res.send({code:200,msg:'login sucess'});
			 }else{
			     res.send({code:301,msg:'login err'});
			 }
		 });
	 });
//3.用户检索
	 router.get('/details',(req,res)=>{
	     var obj=req.query;
		 var $uid=obj.uid;
		 if(!$uid){
		     res.send({code:401,msg:'uid required'});
			 return;
		 }
         pool.query('SELECT * FROM mc_user WHERE uid=?',[$uid],(err,result)=>{
		     if(err)throw err;
			 if(result.length>0){
			     res.send(result);
			 }else{res.send({code:300,msg:'uid err'}
			 )};
		 });
	 });
//4.用户修改
     router.post('/update',(req,res)=>{
	     var obj=req.body;
		 var $uid=obj.uid,$uname=obj.uname,$email=obj.email,$phone=obj.phone,
			 $gender=obj.gender,$user_name=obj.user_name;
		 if(!$uid){
		     res.send({code:401,msg:'uid required'});
			 return;
		 }else if(!$uname){
		     res.send({code:402,msg:'uname required'});
			 return;
		 }else if(!$email){
		     res.send({code:403,msg:'email required'});
			 return;
		 }else if(!$phone){
		     res.send({code:404,msg:'phone required'});
			 return;
		 }else if(!$gender){
		     res.send({code:405,msg:'gender required'});
			 return;
		 }else if(!$user_name){
		     res.send({code:406,msg:'user_name required'});
			 return;
		 }
		 pool.query('UPDATE mc_user SET uname=?,email=?,phone=?,gender=?,user_name=? WHERE uid=?',
			 [$uname,$email,$phone,$gender,$user_name,$uid],(err,result)=>{
		     if(err)throw err;
			 //console.log(result);
			 if(result.affectedRows>0){
			     res.send({code:200,msg:'update sucess'});
			 } else{
			     res.send({code:301,msg:'update err'});
			 }
		 });
	 });
//5.用户列表
     router.get('/list',(req,res)=>{
	     var obj=req.query;
		 var $pno=parseInt(obj.pno);
		 var $count=parseInt(obj.count);
		 console.log(obj);
		 if (!$pno){
			 $pno=1; 
		 }
		 if(!$count){
		     $count=10;
		 }
		 var start=($pno-1)*$count;
		 pool.query('SELECT*FROM mc_user LIMIT ?,?',[start,$count],(err,result)=>{
		     if(err)throw err;
			 res.send(result);
		 });
	 });
//6.用户删除
     router.get('/delete',(req,res)=>{
	     var obj=req.query;
		 var $uid=obj.uid;
		 if (!$uid){
			  res.send({code:401,msg:'uid required'});
			  return;
		 }
		 pool.query('DELETE FROM mc_user WHERE uid=?',[$uid],(err,result)=>{
		     if(err)throw err;
			 if(result.affectedRows>0){
			     res.send({code:200,msg:'delete sucess'});
			 }else{
			     res.send({code:301,msg:'delete err'});
			 }
		 });
	 });
//导出路由
module.exports=router;