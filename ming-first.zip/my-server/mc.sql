SET NAMES UTF8;
DROP DATABASE IF EXISTS mc;
CREATE DATABASE mc CHARSET=UTF8;
USE mc;
/**用户信息**/
CREATE TABLE mc_user(
         uid INT PRIMARY KEY AUTO_INCREMENT,
         uname VARCHAR(32),
	 upwd VARCHAR(32),
	 email VARCHAR(64),
	 phone VARCHAR(16),
	 avatar VARCHAR(128),   #头像图片路径
	 user_name VARCHAR(32), #用户名，如王小明
	 gender INT   #性别 0-女 1-男
);
/**用户信息**/
INSERT INTO mc_user VALUES
(NULL,'dingding','123456','dingding@qq.com','13501234567','img/avatar/default.jpg','丁伟','1')