SET NAMES UTF8;
DROP DATABASE IF EXISTS mc;
CREATE DATABASE mc CHARSET=UTF8;
USE mc;

/**创建表格**/
/**1.华为智能手机型号家族分类表**/
   CREATE TABLE mc_smartphone_family(
     fid INT PRIMARY KEY AUTO_INCREMENT,
	   fname VARCHAR(32)
   );
/**2.华为手机**/
   CREATE TABLE mc_smartphone(
     sid INT PRIMARY KEY AUTO_INCREMENT,
	   family_id INT,         #所属型号家族编号
	   title VARCHAR(128),    #主标题
	   subtitle VARCHAR(128),#副标题
	   price DECIMAL(5,2),   #价格
	   promise VARCHAR(64),     #服务承诺
	   spec VARCHAR(64),      #规格/颜色
     
	   sname VARCHAR(32),         #商品名称
     screen_size VARCHAR(32),   #屏幕大小
	   pixel VARCHAR(32),         #像素
     core VARCHAR(32),          #核心数
     RAM VARCHAR(32),           #运行内存
     memory VARCHAR(32),        #机身存储
     video_card VARCHAR(32),     #分辨率
     cpu_rate VARCHAR(32),      #CPU频率 
	   cpu VARCHAR(32),           #处理器cpu型号
     battery_count  VARCHAR(32), #电池容量
	   screen_material VARCHAR(32),#屏幕材料
	   os VARCHAR(32),         #操作系统
     network_type VARCHAR(32), #网络类型
	   details VARCHAR(1024),  #产品详细说明
     shelf_time BIGINT,     #上架时间
	   sold_count INT,        #已售出的数量
	   is_onsale BOOLEAN      #是否促销
     );
/**3.华为手机图片**/
     CREATE TABLE mc_smartpone_pic(
     pid INT PRIMARY KEY AUTO_INCREMENT,
	   smartphone_id INT,     #手机编号
	   sm VARCHAR(128),       #小图片路径
	   md VARCHAR(128),       #中图片路径
	   lg  VARCHAR(128)       #大图片路径
     );
/**4.用户信息表**/
   CREATE TABLE mc_user(
     uid INT PRIMARY KEY AUTO_INCREMENT,
     uname VARCHAR(32),
	   upwd VARCHAR(32),
	   email VARCHAR(64),
	   phone VARCHAR(16),
	   avatar VARCHAR(128),   #头像图片路径
	   user_name VARCHAR(32), #用户名，如王小明
	   gender INT   #性别 0-女 1-男
   );
/**5.收货地址信息**/
   CREATE TABLE mc_receiver_addrress(
     aid  INT PRIMARY KEY AUTO_INCREMENT,
	   user_id INT,              #用户编号
	   receiver VARCHAR(16),     #接收人姓名
	   province VARCHAR(16),     #省
	   city  VARCHAR(16),        #市
	   county VARCHAR(16),       #县
	   address VARCHAR(128),     #详细地址
	   cellphone  VARCHAR(16)  #手机
   );
/**6.购物车条目**/
   CREATE TABLE mc_shoppingcart_itm(
	   iid INT PRIMARY KEY AUTO_INCREMENT,
		 user_id INT,          #用户编号
		 product_id INT,       #商品编号
		 count INT,            #购买数量
		 is_checked BOOLEAN    #是否已勾选，确认购买
	 );
/**7.用户订单**/
   CREATE TABLE mc_order(
	   aid INT PRIMARY KEY AUTO_INCREMENT,
		 user_id INT,
		 address_id INT,      
		 status INT,          #订单状态
		 order_time BIGINT,   #下单时间
		 pay_time   BIGINT,   #付款时间
		 deliver_time BIGINT, #发货时间
		 received_time BIGINT #签收时间
	 )AUTO_INCREMENT=10000000; 
/**8.用户订单详情表**/
   CREATE TABLE mc_order_detail(
	   did INT PRIMARY KEY AUTO_INCREMENT,
		 order_id INT,    #订单编号
		 product_id INT,  #产品编号
		 count INT        #购买数量
	 );
/**9.首页轮播广告商品**/
   CREATE TABLE mc_index_carousel(
	   cid INT PRIMARY KEY AUTO_INCREMENT,
		 img VARCHAR(128),
		 title VARCHAR(64),
		 href VARCHAR(128)
	 );
/**10.首页商品**/
   CREATE TABLE mc_index_product(
	   pid INT PRIMARY KEY AUTO_INCREMENT,
		 title VARCHAR(64),
		 details VARCHAR(128),
		 pic VARCHAR(128),
		 price DECIMAL(10,2),
		 href VARCHAR(128),
		 seq_recommended TINYINT,
		 seq_new_arrival TINYINT,
		 seq_top_sale  TINYINT
	 );
/**数据导入**/

/**1.华为智能手机型号家族分类**/
INSERT INTO mc_smartphone_family VALUES(
NULL,'华为P20');


/**2.华为手机**/
INSERT INTO mc_smartphone VALUES
         (1,1,'华为P20 大屏5.8英寸 2000万后双摄像头','12期免息','3388.00','免举证退换货','5.8英寸大屏手机 香槟金',
         '华为P20','5.8英寸','2000万后双摄像头','八核','运行6GB','机身存储64GB','2244*1080','2.36GHz','海思Kirin 970',
	 '3400mAh持久待机','TFT LCD(IPS)','Android/安卓','全网通','华为P20 大屏5.8英寸 2000万后双摄像头',
	 '2018-4','20000',1
);


/**3.用户信息**/
INSERT INTO mc_user VALUES
(NULL,'dingding','123456','dingding@qq.com','13501234567','img/avatar/default.jpg','丁伟','1')