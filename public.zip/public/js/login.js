var $phone=$("#phone");
      var $user=$("#user");
      //console.log($user);
      $phone.click(function(){
        var $table=$(".table");
        //console.log($table);
        var html="";
         html=`<div>
            <input type="text" placeholder="手机号"> 
          </div>  
          <div>
            <input type="text" placeholder="图形验证码"> 
          </div>
          <div>
            <input type="text" placeholder="获取短信验证码"> 
          </div> `;
        $table.html(html);
      })
      $user.click(function(){
        var $table=$(".table");
        //console.log($table);
        var html="";
        html=` <div>
            <input type="text" placeholder="邮箱/用户名/已验证手机" id="uname"> 
          </div>  
          <div>
            <input type="password" placeholder="密码" id="upwd"> 
          </div>
          <div>
          <input type="button" value="登录" onclick="login()">
          </div>
		   <div id="d1"></div>`;
        $table.html(html);
      })
      