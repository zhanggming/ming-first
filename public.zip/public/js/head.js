$(function(){
    $.ajax({
       url:"http://localhost:3000/head",
        type:"get",
        dataType:"json",
        })
    
.then(res=>{
   // var {hids,gids}=output1;
    var html=` <nav class="top-nav bg-floor ">
    <ul>
        <li><a href="javascript:;" class="my-red">北京站</a></li>
        <li><a href="javascript:;" class="my-gray">[切换]</a></li>
        <li><a href="javascript:open1();" class="my-gray register" >请注册</a></li>
        <li><a href="javascript:;" class="my-gray login">请登录</a></li>
        <li><a href="javascript:;" class="my-gray">我的美乐乐</a></li>
    </ul>
    <ul>
        <li><a href="javascript:;" class="my-gray">购物车</a></li>
        <li><a href="javascript:;" class="my-gray">关注美乐乐</a></li>
        <li><a href="javascript:;" class="my-gray">帮助中心</a></li>
        <li><a href="javascript:;" class="my-gray">收藏本站</a></li>
    </ul>
    <ul><li><a href="javascript:;" class="my-gray">全国热线：4000098666</a></li></ul>
</nav>
 <div class="top-floor">
     <img src="./img/index/head/logo2.png" alt=""/>
     <img src="./img/index/head/head.gif" alt=""/>
     <div class="top-input">
     <input type="text" class="my-input"/>
     <button class="btn">搜索</button>
     <p>抢20抵200翻倍红包&nbsp;床&nbsp;沙发&nbsp;餐桌椅&nbsp; 实木床&nbsp;床垫大促&nbsp;转角沙发&nbsp;灯饰</p>
     </div>
 </div>
 <div class="head-foot">
   <ul>
     <li><a href="javascript:;">商品分类<div><div></a></li>
     <li><a href="javascript:;">首页</a></li>
     <li><a href="javascript:;">商品分类</a></li>
     <li><a href="javascript:;">家具城</a></li>
     <li><a href="javascript:;">建材城</a></li> 
     <li><a href="javascript:;">家居家饰</a></li>
     <li><a href="javascript:;">团购</a></li>
     <li><a href="javascript:;">体验馆阅木</a></li> 
     <li><a href="javascript:;">晒家图览家居</a></li> 
    </ul>
    <div class="head-mouse"><img src="./img/index/banner/banner2.jpg">
    <img src="./img/index/banner/banner3.jpg">
    <div>
 </div>
<div class="head-foot-b"></div>`;
   $("#header").html(html);
   //鼠标移入移出
   var $li=$(".head-foot>ul>li");
   //console.log($li);
   $li.mouseenter(function(){ 
    //console.log(1)
      var $div=$(".head-mouse")
      $($div).css({display:"block"})
   })
   $li.mouseleave(function(){
   // console.log(2)
    var $div=$(".head-mouse")
      $($div).css({display:"none"})
   })
   var $li=$(".register")
   $li.click(function open1(){
	open("register.html","register");
    })
    var $li=$(".login")
   $li.click(function open1(){
	open("login.html","login");
    }) 
});
})
 