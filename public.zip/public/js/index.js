$(function(){//避免生成全局变量造成全局污染
  $.ajax({
    url:"http://localhost:3000/index",
    type:"get",
    dataType:"json",//自动JSON.parse()
  })//open(    res   )
  //  ↓          ↓
  .then(function(output){
    //data形参接住了ajax抛出的服务端返回的数据对象
    //获得第一个商品对象
    //将片段填充回页面中原父元素内: 
    var {pids,cids,fids,tids,kids,mids,nids,qids,vids}=output;
  //1楼
    var html="";
       html+=`<div class="title"><h2>${pids[0].title}&nbsp;${pids[1].title}</h2></div> 
       <ul>
        <li>
         <a href="javascript:;" class="my-gray my-small">${pids[2].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[3].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[4].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[5].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[6].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[7].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[8].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[9].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[10].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[11].title}</a>
         </li>
         <li>
         <a href="javascript:;" class="my-gray my-small">${pids[2].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[3].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[4].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[5].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[6].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[7].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[8].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[9].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[10].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[11].title}</a>
         </li>
         <li>
         <a href="javascript:;" class="my-gray my-small">${pids[2].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[3].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[4].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[5].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[6].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[7].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[8].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[9].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[10].title}</a>
         <a href="javascript:;" class="my-gray my-small">${pids[11].title}</a>
         </li>
      </ul>`
    $("#fTop>div:nth-child(1)").html(html);
    var html="";
    for(var cid of cids){
        html+=`<ul class="banner-img">
        <li><a href="javascript:;" ><img src="${cids[0].img}" class="show" alt="1"/></a></li>
     </ul>
    <a href="javascript:;" class="ck-left ck-side"><img src="${cids[4].img}" alt=""/></a>
    <a href="javascript:;" class="ck-right ck-side"><img src="${cids[5].img}" alt=""/></a>
    <ul class="ind">
        <li class="active"></li>
        <li ></li>
        <li></li>
        <li></li>
    </ul>`
    }
    $("#fTop>div:nth-child(2)").html(html)
   /*轮播图*/
    var a=1;
    function task(){
     /*图片*/
      a++;
      var $img=$("#fTop>div.f-top-right>ul.banner-img>li>a>img")
          var i=parseInt($img.attr("alt"));        
	        if(i<4) i++;
	        else i=1;
	        $img.attr({
	       	alt:i, src:`./img/index/banner/banner${i}.jpg`
             });
      //console.log($li)
  
      //console.log($li.next())
    }
   var n=setInterval(task,1000);
   function task1(){
       /*点点*/
      var $li=$("#fTop>div.f-top-right>ul.ind>li.active");
      $li.removeClass("active");
      if($li.next().length!=0)
     
      $li.next().addClass("active")
      else 
      $("#fTop>div.f-top-right>ul.ind>li:first-child").addClass("active");
   }
   var n1=setInterval(task1,1000)
   /*左右箭头*/
   var $a=$("#fTop>div.f-top-right>a");
    $a.mouseenter(function(){
      clearInterval(n);
      clearInterval(n1);
    })
    $a.mouseleave(function(){
      n=setInterval(task,1000);
      n1=setInterval(task1,1000);
    })
    $a.click(function(){
          var $img=$("#fTop>div.f-top-right>ul.banner-img>li>a>img")
          var i=parseInt($img.attr("alt"));        
	        if(i<4) i++;
	        else i=1;
	        $img.attr({
	       	alt:i, src:`./img/index/banner/banner${i}.jpg`
             });
             var $li=$("#fTop>div.f-top-right>ul.ind>li.active");
             $li.removeClass("active");
             if($li.next().length!=0)
            
             $li.next().addClass("active")
             else 
             $("#fTop>div.f-top-right>ul.ind>li:first-child").addClass("active");   
       })
    //2楼
      var html=""
      for(var fid of fids){
        html+=`<ul><li>
            <a href="javascript:;">
            <img src="${fid.img}" alt=""/>
            </a>
            <span class="goods-name ">
                <a href="javascript:;" class="my-gray my-small">${fid.title}</a>
            </span>
            <div class="price-div">
                <div class="Left price my-white ">
                    <span>¥</span>
                    <span>${fid.price1}</span>
                </div>
                <div class="discont Left">
                    <p class="discont-p my-small">${fid.discount}</p>
                    <p class="my-white my-small "><span>¥</span><span>${fid.price2}</span></p>
                </div>
                <div class="Right div-a bg-yellow">
                <a href="javascript:;" class=" my-red ">${fid.subtitle}</a>
                </div>
            </div></li></ul>`;
        var $div=$("div.f-second").html(html);
      }
/*3楼*/
        var html=`<div class="Left">
        <a href="javascript:;" class="Left ad">
            <img src="${tids[0].img}" alt=""/>
        </a>
        </div>
        <div class="physical-bg Left">
        <div class="infoSpace Left ">
            <h3 class="infoSpace-title">
            
            <span>${tids[1].title}</span>
            <span class="my-small">${tids[2].title}</span>
            <span class="my-small my-red">${tids[3].count}</span>
            <span class="my-small">${tids[4].title}</span>
            </h3>
            <div class="input-div">
            <span class="Left">${tids[5].title}</span>
            <select name="select" id="#">
                <option value="1">${tids[6].title}</option>
                <option value="2">${tids[7].title}</option>
                <option value="3">${tids[8].title}</option>
            </select>
            <select name="select" id="#">
                <option value="1">${tids[8].title}</option>
            </select>
            </div>
            <div class="input-div input-t">
                <span class="Left">${tids[9].title}</span>
                <select name="select" id="#">
                    <option value="1">${tids[10].title}</option>
                    <option value="2">${tids[11].title}</option>
                    <option value="3">${tids[12].title}</option>
                </select>
            </div>
            <div class="input-div input-t">
                <span class="Left">${tids[13].title}</span>
                <input name="select" placeholder="${tids[14].title}"  id="#">
                </input>
            </div>
            <a href="javascript:;" class="send Left"><input type="submit" value="${tids[15].title}"/></a>
        </div>
        <div class="physical-slide Right">
            <h3 class="slideTitle">${tids[16].title}</h3>
            <div id="app">
            <ul class="d1">
                <li>${pids[1].title}</li>
                <li>${pids[2].title}</li>
                <li>${pids[3].title}</li>
                <li>${pids[4].title}</li>
                <li>${pids[5].title}</li>
                <li>${pids[6].title}</li>
                <li>${pids[7].title}</li>
                <li>${pids[8].title}</li>
                <li>${pids[9].title}</li>
                <li>${pids[10].title}</li>
                <li>${pids[11].title}</li>
                <li>${pids[12].title}</li>
                <li>${pids[1].title}</li>
                <li>${pids[2].title}</li>
                <li>${pids[3].title}</li>
                <li>${pids[4].title}</li>
                <li>${pids[5].title}</li>
                <li>${pids[6].title}</li>
                <li>${pids[7].title}</li>
                <li>${pids[8].title}</li>
                <li>${pids[9].title}</li>
                <li>${pids[10].title}</li>
                <li>${pids[11].title}</li>
                <li>${pids[12].title}</li>
            </ul>
         </div>
        </div>
  </div>
   </div>`;
      var $div=$("div.physical-store").html(html)
      var $li=$("#app>.d1")
      var b=-247;
      //console.log(typeof($ul))
      function task3(){
          b+=1;
          $($li).css({
           bottom:b
           })
          if(b>190){
              b=-247
              $($li).css({
               bottom:b
            })
              
          }
      }
      var n3=setInterval(task3,20)
/*4楼*/
      var html=`<div class="h3-title">
      <h3 >
      <img src="${kids[0].img}" alt=""/>
      </h3>
  </div>
  <div class="first-div">
    <div class="second-div Left">
        <ul class="leftUl">
            <li><a href="javascript:;" class="my-small my-gray"><span>${mids[0].title}</span></a></li>
            <li><a href="javascript:;" class="my-small my-gray"><span>${mids[1].title}</span></a></li>
            <li><a href="javascript:;" class="my-small my-gray"><span>${mids[2].title}</span></a></li>
            <li><a href="javascript:;" class="my-small my-gray"><span>${mids[3].title}</span></a></li>
            <li><a href="javascript:;" class="my-small my-gray"><span>${mids[4].title}</span></a></li>
            <li><a href="javascript:;" class="my-small my-gray"><span>${mids[5].title}</span></a></li>
            <li><a href="javascript:;" class="my-small my-gray"><span>${mids[6].title}</span></a></li>
            <li><a href="javascript:;" class="my-small my-gray"><span>${mids[7].title}</span></a></li>
            <li><a href="javascript:;" class="my-small my-gray"><span>${mids[8].title}</span></a></li>
        </ul>
        <a href="javascript:;"><img src="${kids[1].img}" alt=""/></a>
     </div>
     <div class="right-div Right">
                <img src="${kids[2].img}" alt=""/>
     </div>`;
     $div=$("div.top-div").html(html);
 /*5楼*/
     var html=""
      for(var nid of nids){
        html+=`
        <li>
            <a href="javascript:;">
            <img src="${nid.img}" alt=""/>
            </a>
            <div class="goods-info">
            <span class="goods-title my-small ">${nid.title}</span>
            <div class="price">
            <strong class="my-red my-small ">¥${nid.price1}</strong>
            <del class="my-gray my-small">¥${nid.price2}</del>
            <i class="my-small">${nid.h1}</i>
            <span class="my-small">
                <b class="my-gray">|</b>
             ${nid.h2}:&nbsp;<b>${nid.countent}</b>
            </span>
            </div>
            </div>
        </li>`;
        var $div=$("div.bottom1-div>ul").html(html);
      }
      var html=`<div class="h3-title">
      <h3 >
          <img src="${qids[0].img}" alt=""/>
      </h3>
  </div>
  <div class="first-div">
      <div class="bottom-div">
          <ul class="goods-ul">
              <li>
                  <a href="javascript:;">
                      <img src="${qids[1].img}" alt=""/>
                  </a>
                  <div class="goods-info">
                      <span class="goods-title my-small ">${qids[1].title}</span>
                      <div class="price">
                          <strong class="my-red my-small ">￥${qids[1].price1}</strong>
                          <del class="my-gray my-small">¥${qids[1].price}</del>
                          <i class="my-small">${qids[1].h1}</i>
                    <span class="my-small">
                        <b class="my-gray">|</b>
                        ${qids[1].h2}:&nbsp;<b>${qids[1].countent}</b>
                    </span>
                      </div>
                  </div>
              </li>
              <li>
              <a href="javascript:;">
                  <img src="${qids[2].img}" alt=""/>
              </a>
              <div class="goods-info">
                  <span class="goods-title my-small ">${qids[2].title}</span>
                  <div class="price">
                      <strong class="my-red my-small ">￥${qids[2].price1}</strong>
                      <del class="my-gray my-small">¥${qids[2].price}</del>
                      <i class="my-small">${qids[2].h1}</i>
                <span class="my-small">
                    <b class="my-gray">|</b>
                    ${qids[2].h2}:&nbsp;<b>${qids[2].countent}</b>
                </span>
                  </div>
              </div>
          </li>
          <li>
          <a href="javascript:;">
              <img src="${qids[3].img}" alt=""/>
          </a>
          <div class="goods-info">
              <span class="goods-title my-small ">${qids[3].title}</span>
              <div class="price">
                  <strong class="my-red my-small ">￥${qids[3].price1}</strong>
                  <del class="my-gray my-small">¥${qids[3].price}</del>
                  <i class="my-small">${qids[3].h1}</i>
            <span class="my-small">
                <b class="my-gray">|</b>
                ${qids[3].h2}:&nbsp;<b>${qids[3].countent}</b>
            </span>
              </div>
          </div>
      </li>
          </ul>
      </div>
  </div>`;    
  $("div.last-div").html(html);
   
var html=`<div class="h3-title">
<h3 >
    <img src="${vids[0].img}" alt=""/>
</h3>
</div>
<div class="first-div">
<div class="bottom-div">
    <ul class="goods-ul">
        <li>
            <a href="javascript:;">
                <img src="${vids[1].img}" alt=""/>
            </a>
            <div class="goods-info">
                <span class="goods-title my-small ">${vids[1].title}</span>
                <div class="price">
                    <strong class="my-red my-small ">¥${vids[1].price1}</strong>
                    <del class="my-gray my-small">¥${vids[1].price2}</del>
                    <i class="my-small">${vids[1].h1}</i>
              <span class="my-small">
                  <b class="my-gray">|</b>
                  ${vids[1].h2}:&nbsp;<b>${vids[1].countent}</b>
              </span>
                </div>
            </div>
        </li>
        <li>
            <a href="javascript:;">
                <img src="${vids[2].img}" alt=""/>
            </a>
            <div class="goods-info">
                <span class="goods-title my-small ">${vids[2].title}</span>
                <div class="price">
                    <strong class="my-red my-small ">¥${vids[2].price1}</strong>
                    <del class="my-gray my-small">¥${vids[2].price2}</del>
                    <i class="my-small">${vids[2].h1}</i>
              <span class="my-small">
                  <b class="my-gray">|</b>
                  ${vids[2].h2}:&nbsp;<b>${vids[2].countent}</b>
              </span>
                </div>
            </div>
        </li>
        <li>
            <a href="javascript:;">
                <img src="${vids[3].img}" alt=""/>
            </a>
            <div class="goods-info">
                <span class="goods-title my-small ">${vids[3].title}</span>
                <div class="price">
                    <strong class="my-red my-small ">¥${vids[3].price1}</strong>
                    <del class="my-gray my-small">¥${vids[3].price2}</del>
                    <i class="my-small">${vids[3].h1}</i>
              <span class="my-small">
                  <b class="my-gray">|</b>
                  ${vids[3].h2}:&nbsp;<b>${vids[3].countent}</b>
              </span>
                </div>
            </div>
        </li>
        <li>
        <a href="javascript:;">
            <img src="${vids[4].img}" alt=""/>
        </a>
        <div class="goods-info">
            <span class="goods-title my-small ">${vids[4].title}</span>
            <div class="price">
                <strong class="my-red my-small ">¥${vids[4].price1}</strong>
                <del class="my-gray my-small">¥${vids[4].price2}</del>
                <i class="my-small">${vids[4].h1}</i>
          <span class="my-small">
              <b class="my-gray">|</b>
              ${vids[4].h2}:&nbsp;<b>${vids[4].countent}</b>
          </span>
            </div>
        </div>
    </li>
    </ul>
</div>`;
$("div.last-product").html(html);
 


})
}) 
